ROADLOG APK v2 — മലയാളം നിർദ്ദേശങ്ങൾ

1) GitHub-ൽ നിങ്ങളുടെ പഴയ driver-trip-log repository തുറക്കുക.
2) ZIP-ലുള്ള index.html ഫയൽ repository-യുടെ മുകളിലെ index.html-ന് പകരം upload ചെയ്യുക.
3) .github/workflows/build-roadlog.yml എന്ന path-ൽ ഉള്ള workflow ഫയൽ പുതിയത് കൊണ്ട് replace ചെയ്യുക. ആ folder/file ഇല്ലെങ്കിൽ അതേ പേരിൽ create ചെയ്യുക.
4) Commit changes ചെയ്യുക.
5) Actions → Build ROADLOG APK → ഏറ്റവും പുതിയ successful run → Artifacts → ROADLOG-APK download ചെയ്യുക.
6) ZIP extract ചെയ്ത് app-debug.apk TECNO ഫോണിൽ install ചെയ്യുക. Android ചോദിച്ചാൽ browser/file manager-ന് install permission അനുവദിക്കുക.

PDF: Reports → Kilometer PDF അല്ലെങ്കിൽ Fuel PDF അമർത്തുക. Android Print screen തുറക്കും. അവിടെ Save as PDF തിരഞ്ഞെടുക്കുക; Downloads-ൽ save ചെയ്യുക.

Backup: Settings → Backup Data അമർത്തി ROADLOG-backup.json Downloads/Drive-ൽ save ചെയ്യുക. Restore Backup അമർത്തി ആ JSON ഫയൽ തിരഞ്ഞെടുക്കുക.

Data ഓരോ save/edit-നും ഫോണിലെ app storage-ൽ auto-save ആകും. App uninstall ചെയ്യുകയോ app data clear ചെയ്യുകയോ ചെയ്താൽ local data മായാം. അതിനാൽ ഇടയ്ക്കിടെ Backup Data എടുക്കുക.
